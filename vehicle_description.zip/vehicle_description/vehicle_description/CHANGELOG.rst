^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package vehicle_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2019-03-21)
-------------------
* Feature/vehicle description (`#1848 <https://github.com/CPFL/Autoware/issues/1848>`_)
* Contributors: Masaya Kataoka
